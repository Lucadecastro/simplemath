def is_number(n):
    """Verifica se o valor fornecido é um número."""
    return isinstance(n, (int, float))
